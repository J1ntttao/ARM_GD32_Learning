
#include "main.h"
#include "gd32f4xx.h"
#include "systick.h"
#include "u8g2/u8g2.h"
#include <stdio.h>
#include <stdint.h>
#include <stdio.h>
#include "USART0.h"
#include "I2C.h"

void USART0_on_recv(uint8_t* data, uint32_t len) {
}

static void GPIO_config(rcu_periph_enum rcu, uint32_t port, uint32_t pin) {
  // 1. ʱ�ӳ�ʼ��
  rcu_periph_clock_enable(rcu);
  // 2. ����GPIO �������ģʽ
  gpio_mode_set(port, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, pin);
  // 3. ����GPIO ���ѡ��
  gpio_output_options_set(port, GPIO_OTYPE_OD, GPIO_OSPEED_MAX, pin);
  // 4. Ĭ�������ƽ
  gpio_bit_write(port, pin, RESET);
}

void test_draw(u8g2_t *u8g2);
/* USER CODE BEGIN PFP */
uint8_t u8g2_gpio_and_delay_gd32(U8X8_UNUSED u8x8_t *u8x8, U8X8_UNUSED uint8_t msg, U8X8_UNUSED uint8_t arg_int, U8X8_UNUSED void *arg_ptr)
{
  switch(msg) {
  //Initialize SPI peripheral
  case U8X8_MSG_GPIO_AND_DELAY_INIT:
    /* HAL initialization contains all what we need so we can skip this part. */

    GPIO_config(RCU_GPIOB, GPIOB, GPIO_PIN_6);
    GPIO_config(RCU_GPIOB, GPIOB, GPIO_PIN_7);
    break;

  //Function which implements a delay, arg_int contains the amount of ms
  case U8X8_MSG_DELAY_MILLI:
    delay_1ms(arg_int);

    break;
  //Function which delays 10us
  case U8X8_MSG_DELAY_10MICRO:
    delay_1us(10);
    /*for (uint16_t n = 0; n < 320; n++)
    {
      __NOP();
    }*/

    break;
  //Function which delays 100ns
  case U8X8_MSG_DELAY_100NANO:
    __NOP();

    break;
  case U8X8_MSG_GPIO_I2C_CLOCK:

    if (arg_int) gpio_bit_write(I2C0_SCL_PORT, I2C0_SCL_PIN, SET);
    else gpio_bit_write(I2C0_SCL_PORT, I2C0_SCL_PIN, RESET);;

    break;

  case U8X8_MSG_GPIO_I2C_DATA:
    if (arg_int) gpio_bit_write(I2C0_SDA_PORT, I2C0_SDA_PIN, SET);
    else gpio_bit_write(I2C0_SDA_PORT, I2C0_SDA_PIN, RESET);
    break;

  default:
    return 0; //A message was received which is not implemented, return 0 to indicate an error
  }

  return 1; // command processed successfully.
}
//unsigned char bird[] = {
//0x18, 0x64, 0xa6, 0x99, 0x81, 0xa7, 0x71, 0x55, 0x56, 0x7c, 0x10,
//};

unsigned char bird[] = {
  0x60,0x00,0x08,0x00,0x26,0x00,0x21,0x02,0x41,0x03,0xC0,0x07,0xE4,0x07,0xCC,0x03,0x00,0x00/* (12 X 9 )*/
};


int x1;
int y1;
int x2;
int y2;
int bs;
int bird_x;
int bird_y;
long score;
u8g2_t u8g2;
void test_bird_init(void)
{
  x1 = 128; // ��1��ֵ
  x2 = 192; // ��2��ֵ
  y1 = rand()% 42 + 1; // ��1�߶����
  y2 = rand()% 42 + 1; // ��2�߶����

  bs = 32;
  bird_x = 20;
  bird_y = 10;
  score = 0;


  u8g2_Setup_ssd1306_i2c_128x64_noname_f(&u8g2, U8G2_R0, u8x8_byte_sw_i2c, u8g2_gpio_and_delay_gd32);
  u8g2_InitDisplay(&u8g2); // send init sequence to the display, display is in sleep mode after this,
  u8g2_SetPowerSave(&u8g2, 0); // wake up display


  delay_1ms(200);

  printf("init success\r\n");


  //u8g2_DrawLine(&u8g2, 0,0, 127, 63);
  //u8g2_DrawLine(&u8g2, 127,0 , 0,63);
  //u8g2_SendBuffer(&u8g2); // �����ݷ��͵���Ļ

  u8g2_ClearBuffer(&u8g2);
  test_draw(&u8g2);

}

volatile uint64_t game_tick = 0;
volatile uint64_t key_tick = 0;

// ���ʱ����
#define INTERVAL_CHECK(ctick, interval)                \
	/* ����Timer��tick��� */														\
	if(get_sys_tick() < ctick) ctick = 0;					\
	/* �����ʱ��С��Ԥ��ֵ */													\
	if((get_sys_tick() - ctick) < interval){      \
		/* ���أ���ִ������ */                             \
		return;                                           \
	}	                                                  \
	/* ��¼���µ�tick */																	\
	ctick = get_sys_tick();                       \


void test_bird_task() {
  INTERVAL_CHECK(game_tick, 30);

  test_draw(&u8g2);

  if(bird_y < 0) {
    bird_y = 0;
  }
  if(bird_y > 64) {
    //is_fail = 1;
    bird_y = 64;
  }

  if(x1==-10) {
    x1 = 128;
    y1 = rand()% 42 + 1;
  }
  if(x2==-10) {
    x2 = 128;
    y2 = rand()% 42 + 1;
  }
  if (x1 >= bird_x && x1 <= bird_x + 12) {
    if(bird_y < y1 || bird_y+8 > y1+25) {
      //is_fail = 1;
    }
  }
  if (x2 >= bird_x && x2 <= bird_x + 12) {
    if(bird_y < y2 || bird_y+8 > y2+25) {
      //is_fail = 1;
    }
  }

  if(x1==16 || x2==16) {
    score++;
  }

}


void test_draw(u8g2_t *u8g2)
{
  // �����Ļ
  u8g2_ClearBuffer(u8g2);
  // �ܵ�����ˮƽ����
  x1 = x1 - 2;
  x2 = x2 - 2;

  // �Ϲܺ��¹�֮��ļ��
  int dist = 25;

  // ���ƹ�1-��
  u8g2_DrawBox(u8g2,x1,0,10,y1);
  u8g2_DrawBox(u8g2,x1-2,y1-6,14,6);
  // ���ƹ�1-��
  u8g2_DrawBox(u8g2,x1,y1+dist,10,64 - y1);
  u8g2_DrawBox(u8g2,x1-2,y1+dist,14,6);

  // ���ƹ�2-��
  u8g2_DrawBox(u8g2,x2,0,10,y2);
  u8g2_DrawBox(u8g2,x2-2,y2-6,14,6);
  // ���ƹ�2-��
  u8g2_DrawBox(u8g2,x2,y2+dist,10,64 - y2);
  u8g2_DrawBox(u8g2,x2-2,y2+dist,14,6);

  // ������½�����
  bs = bs-5;
  bird_y = bird_y - bs / 10;

  // ������
  u8g2_DrawXBM(u8g2,bird_x, bird_y, 12, 9, bird);
  // �����ݻ��Ƶ���Ļ��
  u8g2_SendBuffer(u8g2);
  // ÿ��30ms ˢ��һ��
}

void test_bird_key() {
  // ���������µ�ʱ�򣬸����������
  bs = 32;
}
#include "bsp_keys.h"


void Keys_on_keydown(uint8_t index) {
  test_bird_key();
}
void Keys_on_keyup(uint8_t index) {

}

void scan_keys_task() {

  INTERVAL_CHECK(key_tick, 5);

  Keys_scan();
}

int main() {
  systick_config();
  USART0_init();

  Keys_init();
  test_bird_init();

  while(1) {
    scan_keys_task();

    test_bird_task();
  }

  return 0;
}