#include "EXTI.h"

/**********************************************************
 * @brief �ⲿ�ж��������ú���
 * @param 
 **********************************************************/
static void EXTI_config(
	rcu_periph_enum rcu, uint32_t gpio, uint32_t pull_up_down, uint32_t pin, 
	uint8_t exti_port, uint8_t exti_pin,
	exti_line_enum linex, exti_trig_type_enum trig_type,
	uint8_t nvic_irq,  uint8_t nvic_irq_pre_priority,
                     uint8_t nvic_irq_sub_priority){
	// GPIO���� ---------------------------------
	// ����rcu
	rcu_periph_clock_enable(rcu);
	// ����Ϊ����ģʽ
	gpio_mode_set(gpio, GPIO_MODE_INPUT, pull_up_down, pin);
	
	// EXTI�ⲿ�ж� ---------------------------------
	rcu_periph_clock_enable(RCU_SYSCFG);
	
	/* ���ⲿ�ж�line���ӵ�PA0���� connect key EXTI line to key GPIO pin */
	syscfg_exti_line_config(exti_port, exti_pin);
	/* ��ʼ����������Ե configure key EXTI line */
  exti_init(linex, EXTI_INTERRUPT, trig_type);
        
	// NVIC�ж� ---------------------------------
	// ����EXTI1���ȼ�
	nvic_irq_enable(nvic_irq, nvic_irq_pre_priority, nvic_irq_sub_priority);
	// ����EXTI_1���жϹ��� enable the interrupts from EXTI line x
	exti_interrupt_enable(linex);
	// ����һ���źţ������޷��������߸ճ�ʼ���ʹ���
	exti_interrupt_flag_clear(linex);
}

/**********************************************************
 * @brief �ⲿ�ж�����������
 * @param linex �ⲿ�ж���
 * @param nvic_irq_pre_priority ��ռ���ȼ�
 * @param nvic_irq_sub_priority ��Ӧ���ȼ�
 **********************************************************/
static void EXTI_config_soft(exti_line_enum linex,
	uint8_t nvic_irq,  uint8_t nvic_irq_pre_priority,
                     uint8_t nvic_irq_sub_priority ) {
  // EXTI�ⲿ�ж� ---------------------------------
  /* ��ʼ����������Ե configure key EXTI line */
  exti_init(linex, EXTI_INTERRUPT, EXTI_TRIG_NONE);
  // NVIC�ж� ---------------------------------
  // ����EXTI���ȼ�
  nvic_irq_enable(nvic_irq, nvic_irq_pre_priority, nvic_irq_sub_priority);
  // ����EXTI���жϹ��� enable the interrupts from EXTI line x
  exti_interrupt_enable(linex);
  // ����һ���źţ������޷��������߸ճ�ʼ���ʹ���
  exti_interrupt_flag_clear(linex);
}

void EXTI_init(){

// ---------------------------------------------
#if USE_EXTI0
	#if EXTI0_SOFT
	EXTI_config_soft(EXTI_0, EXTI0_IRQn, EXTI0_IRQ_PRI);
	#else
	EXTI_config(
		EXTI0_RCU, EXTI0_GPIO, EXTI0_PUPD, GPIO_PIN_0, // GPIO
		EXTI0_SOUCE_PORT, EXTI_SOURCE_PIN0, // syscfg
		EXTI_0, EXTI0_TRIG_TYPE,
		EXTI0_IRQn, EXTI0_IRQ_PRI);
	#endif
#endif

// ---------------------------------------------
#if USE_EXTI1
	#if EXTI1_SOFT
	EXTI_config_soft(EXTI_1, EXTI1_IRQn, EXTI1_IRQ_PRI);
	#else
	EXTI_config(
		EXTI1_RCU, EXTI1_GPIO, EXTI1_PUPD, GPIO_PIN_1, // GPIO
		EXTI1_SOUCE_PORT, EXTI_SOURCE_PIN1, // syscfg
		EXTI_1, EXTI1_TRIG_TYPE,
		EXTI1_IRQn, EXTI1_IRQ_PRI);
	#endif
#endif
	
// ---------------------------------------------
#if USE_EXTI2
	#if EXTI1_SOFT
	EXTI_config_soft(EXTI_2, EXTI2_IRQn, EXTI2_IRQ_PRI);
	#else
	EXTI_config(
		EXTI2_RCU, EXTI2_GPIO, EXTI2_PUPD, GPIO_PIN_2, // GPIO
		EXTI2_SOUCE_PORT, EXTI_SOURCE_PIN2, // syscfg
		EXTI_2, EXTI2_TRIG_TYPE,
		EXTI2_IRQn, EXTI2_IRQ_PRI);
	#endif
#endif

// ---------------------------------------------
#if USE_EXTI5
	#if EXTI5_SOFT
	EXTI_config_soft(EXTI_5, EXTI5_9_IRQn, EXTI5_IRQ_PRI);
	#else
	EXTI_config(
		EXTI5_RCU, EXTI5_GPIO, EXTI5_PUPD, GPIO_PIN_5, // GPIO
		EXTI5_SOUCE_PORT, EXTI_SOURCE_PIN5, 					 // syscfg
		EXTI_5, EXTI5_TRIG_TYPE,											 // exti
		EXTI5_9_IRQn, EXTI5_IRQ_PRI);									 // nvic
	#endif
#endif
}

/*!
    \brief    ��������ָ���ⲿ�ж�
    \param[in]  linex: EXTI line number, refer to exti_line_enum
                only one parameter can be selected which is shown as below:
      \arg        EXTI_x (x=0..22): EXTI line x
*/
void EXTI_trig_soft(exti_line_enum linex){
		exti_software_interrupt_enable(linex);
}

#if USE_EXTI0
void EXTI0_IRQHandler() {

  if(SET == exti_interrupt_flag_get(EXTI_0)) {
    exti_interrupt_flag_clear(EXTI_0);
		EXTI0_on_trig();
  }
}
#endif

#if USE_EXTI1
void EXTI1_IRQHandler() {

  if(SET == exti_interrupt_flag_get(EXTI_1)) {
    exti_interrupt_flag_clear(EXTI_1);
		EXTI1_on_trig();
  }
}
#endif

#if USE_EXTI2
void EXTI2_IRQHandler() {

  if(SET == exti_interrupt_flag_get(EXTI_2)) {
    exti_interrupt_flag_clear(EXTI_2);
		EXTI2_on_trig();
  }
}

#endif

#if USE_EXTI5 || USE_EXTI6
void EXTI5_9_IRQHandler(){
	#if USE_EXTI5
  if(SET == exti_interrupt_flag_get(EXTI_5)) {
    exti_interrupt_flag_clear(EXTI_5);
		EXTI5_on_trig();
  }
	#endif
	#if USE_EXTI6
  if(SET == exti_interrupt_flag_get(EXTI_6)) {
    exti_interrupt_flag_clear(EXTI_6);
		EXTI6_on_trig();
  }
	#endif
}
#endif