#ifndef __I2C_CONFIG_H__
#define __I2C_CONFIG_H__

#include "gd32f4xx.h"

#define USE_I2C0		1
#define USE_I2C1		0
#define USE_I2C2		0

typedef enum {

	I2C_ERR_OK = 0,
	// �豸��ַ������ 1
	I2C_ERR_DEVICE_ADDR,
	// �Ĵ�����ַ���� 2
	I2C_ERR_REGISTER,
	// д�쳣 3
	I2C_ERR_WRITE,
	// ���쳣 4
	I2C_ERR_READ,
	
} I2C_ERR_T;
// ============================I2C0========================
#if USE_I2C0

#define I2C0_SOFT 		1
#define I2C0_SPEED		100000U

// PB6,PB8
#define I2C0_SCL_RCU		RCU_GPIOB
#define I2C0_SCL_PORT		GPIOB
#define I2C0_SCL_PIN		GPIO_PIN_6

// PB7,PB9
#define I2C0_SDA_RCU		RCU_GPIOB
#define I2C0_SDA_PORT		GPIOB
#define I2C0_SDA_PIN		GPIO_PIN_7

#endif

// ============================I2C1========================
#if USE_I2C1

#define I2C1_SOFT 			1
#define I2C1_SPEED			100000U
// PB10,PF1,PH4	
#define I2C1_SCL_RCU		RCU_GPIOB
#define I2C1_SCL_PORT		GPIOB
#define I2C1_SCL_PIN		GPIO_PIN_6
// PF0,PH5,PB11,PC12,PB3
#define I2C1_SDA_RCU		RCU_GPIOB
#define I2C1_SDA_PORT		GPIOB
#define I2C1_SDA_PIN		GPIO_PIN_7
#endif

// ============================I2C2========================
#if USE_I2C2

#define I2C2_SOFT 			1
#define I2C2_SPEED			100000U
#define I2C2_SCL_RCU		RCU_GPIOB
#define I2C2_SCL_PORT		GPIOB
#define I2C2_SCL_PIN		GPIO_PIN_6
#define I2C2_SDA_RCU		RCU_GPIOB
#define I2C2_SDA_PORT		GPIOB
#define I2C2_SDA_PIN		GPIO_PIN_7

#endif

#endif