
#include "main.h"
#include "gd32f4xx.h"
#include "systick.h"
#include "u8g2/u8g2.h"
#include <stdio.h>
#include <stdint.h>
#include <stdio.h>
#include "USART0.h"
#include "I2C.h"
#include <stdio.h>
#include <string.h>
#include "systick.h"
//#include "spi_oled.h"
#include "bsp_keys.h"


void USART0_on_recv(uint8_t* data, uint32_t len){
}

volatile uint64_t game_tick = 0;
volatile uint64_t key_tick = 0;

// ���ʱ����
#define INTERVAL_CHECK(ctick, interval)                \
	/* ����Timer��tick��� */														\
	if(get_sys_tick() < ctick) ctick = 0;					\
	/* �����ʱ��С��Ԥ��ֵ */													\
	if((get_sys_tick() - ctick) < interval){      \
		/* ���أ���ִ������ */                             \
		return;                                           \
	}	                                                  \
	/* ��¼���µ�tick */																	\
	ctick = get_sys_tick();                       \
	

static void gpio_i2c_init(){
  // ��GPIO���г�ʼ��
  rcu_periph_clock_enable(RCU_GPIOB);
  // PB6 SCL
  gpio_mode_set(GPIOB,GPIO_MODE_OUTPUT,GPIO_PUPD_PULLUP,GPIO_PIN_6);
  gpio_output_options_set(GPIOB,GPIO_OTYPE_OD,GPIO_OSPEED_MAX,GPIO_PIN_6);
  
  // PB7 SDA
  gpio_mode_set(GPIOB,GPIO_MODE_OUTPUT,GPIO_PUPD_PULLUP,GPIO_PIN_7);
  gpio_output_options_set(GPIOB,GPIO_OTYPE_OD,GPIO_OSPEED_MAX,GPIO_PIN_7);
}



static uint8_t u8g2_gpio_and_delay_gd32(U8X8_UNUSED u8x8_t *u8x8, U8X8_UNUSED uint8_t msg, U8X8_UNUSED uint8_t arg_int, U8X8_UNUSED void *arg_ptr)
{
	switch(msg){
		//Initialize SPI peripheral
		case U8X8_MSG_GPIO_AND_DELAY_INIT:
			delay_1ms(200);
      break;
		//Function which implements a delay, arg_int contains the amount of ms
		case U8X8_MSG_DELAY_MILLI:
      delay_1ms(arg_int);

      break;
		//Function which delays 10us
		case U8X8_MSG_DELAY_10MICRO:
      delay_1us(10);
      break;
		//Function which delays 100ns
		case U8X8_MSG_DELAY_100NANO:
      __NOP();

		break;
		//Function to define the logic level of the clockline
		case U8X8_MSG_GPIO_I2C_CLOCK:
			if (arg_int) gpio_bit_write(GPIOB, GPIO_PIN_6, SET);
			else gpio_bit_write(GPIOB, GPIO_PIN_6, RESET);

      break;
		//Function to define the logic level of the data line to the display
		case U8X8_MSG_GPIO_I2C_DATA:
			if (arg_int) gpio_bit_write(GPIOB, GPIO_PIN_7, SET);
			else gpio_bit_write(GPIOB, GPIO_PIN_7, RESET);

      break;

		//Function to define the logic level of the RESET line
		case U8X8_MSG_GPIO_RESET:
			//if (arg_int) gpio_bit_write(LCD_RESET_GPIO_Port, LCD_RESET_Pin, SET);
			//else gpio_bit_write(LCD_RESET_GPIO_Port, LCD_RESET_Pin, RESET);

      break;
    
    
    
    
		default:
			return 0; //A message was received which is not implemented, return 0 to indicate an error
	}

	return 1; // command processed successfully.
}


struct menu_entry_type
{
  const uint8_t *font;
  uint16_t icon;
  const char *name;
};

struct menu_state
{
  int16_t menu_start;		/* in pixel */
  int16_t frame_position;		/* in pixel */
  uint8_t position;			/* position, array index */
};

/*
  Icon configuration
  Width and height must match the icon font size
  GAP: Space between the icons
  BGAP: Gap between the display border and the cursor.
*/
#define ICON_WIDTH 32
#define ICON_HEIGHT 32
#define ICON_GAP 4
#define ICON_BGAP 16
#define ICON_Y 32+ ICON_GAP

struct menu_entry_type menu_entry_list[] =
{
  { u8g2_font_open_iconic_embedded_4x_t, 65, "Clock Setup"},
  { u8g2_font_open_iconic_embedded_4x_t, 66, "Gear Game"},
  { u8g2_font_open_iconic_embedded_4x_t, 67, "Flash Light"},
  { u8g2_font_open_iconic_embedded_4x_t, 68, "Home"},
  { u8g2_font_open_iconic_embedded_4x_t, 72, "Configuration"},
  { NULL, 0, NULL } 
};

int8_t button_event = 0;		// set this to 0, once the event has been processed

void check_button_event(void)
{
  if ( button_event == 0 ){
    //button_event = u8g2.getMenuEvent();
    button_event = Keys_scan();
  }
    
}


void draw(u8g2_t* u8g2,struct menu_state *state)
{
  int16_t x;
  uint8_t i;
  x = state->menu_start;
  i = 0;
  while( menu_entry_list[i].icon > 0 )  
  {
    if ( x >= -ICON_WIDTH && x < u8g2_GetDisplayWidth(u8g2) )
    {
      u8g2_SetFont(u8g2,menu_entry_list[i].font);
      u8g2_DrawGlyph(u8g2,x, ICON_Y, menu_entry_list[i].icon );
    }
    i++;
    x += ICON_WIDTH + ICON_GAP;
    check_button_event();
  }
  u8g2_DrawFrame(u8g2,state->frame_position-1, ICON_Y-ICON_HEIGHT-1, ICON_WIDTH+2, ICON_WIDTH+2);
  u8g2_DrawFrame(u8g2,state->frame_position-2, ICON_Y-ICON_HEIGHT-2, ICON_WIDTH+4, ICON_WIDTH+4);
  u8g2_DrawFrame(u8g2,state->frame_position-3, ICON_Y-ICON_HEIGHT-3, ICON_WIDTH+6, ICON_WIDTH+6);
  check_button_event();
}


void to_right(u8g2_t* u8g2,struct menu_state *state)
{
  if ( menu_entry_list[state->position+1].font != NULL )
  {
    if ( (int16_t)state->frame_position+ 2*(int16_t)ICON_WIDTH + (int16_t)ICON_BGAP < (int16_t)u8g2_GetDisplayWidth(u8g2) )
    {
      state->position++;
      state->frame_position += ICON_WIDTH + (int16_t)ICON_GAP;
    }
    else
    {
      state->position++;      
      state->frame_position = (int16_t)u8g2_GetDisplayWidth(u8g2) - (int16_t)ICON_WIDTH - (int16_t)ICON_BGAP;
      state->menu_start = state->frame_position - state->position*((int16_t)ICON_WIDTH + (int16_t)ICON_GAP);
    }
  }
}

void to_left(struct menu_state *state)
{
  if ( state->position > 0 )
  {
    if ( (int16_t)state->frame_position >= (int16_t)ICON_BGAP+(int16_t)ICON_WIDTH+ (int16_t)ICON_GAP )
    {
      state->position--;
      state->frame_position -= ICON_WIDTH + (int16_t)ICON_GAP;
    }    
    else
    {
      state->position--; 
      state->frame_position = ICON_BGAP;
      state->menu_start = state->frame_position - state->position*((int16_t)ICON_WIDTH + (int16_t)ICON_GAP);      
    }
  }
}


uint8_t towards_int16(int16_t *current, int16_t dest)
{
  if ( *current < dest )
  {
    (*current)++;
    return 1;
  }
  else if ( *current > dest )
  {
    (*current)--;
    return 1;
  }
  return 0;
}

uint8_t towards(struct menu_state *current, struct menu_state *destination)
{
  uint8_t r = 0;
  uint8_t i;
  for( i = 0; i < 6; i++ )
  {
    r |= towards_int16( &(current->frame_position), destination->frame_position);
    r |= towards_int16( &(current->menu_start), destination->menu_start);
  }
  return r;
}



struct menu_state current_state = { ICON_BGAP, ICON_BGAP, 0 };
struct menu_state destination_state = { ICON_BGAP, ICON_BGAP, 0 };

void loop(u8g2_t* u8g2) {
  do
  {
    u8g2_FirstPage(u8g2);
    do
    {
      draw(u8g2,&current_state);  
      u8g2_SetFont(u8g2,u8g2_font_helvB10_tr);  
      //u8g2_SetCursor((u8g2.getDisplayWidth()-u8g2.getStrWidth(menu_entry_list[destination_state.position].name))/2,u8g2.getDisplayHeight()-5);
      //u8g2.print(menu_entry_list[destination_state.position].name);
      
      int x = (u8g2_GetDisplayWidth(u8g2)-u8g2_GetStrWidth(u8g2,menu_entry_list[destination_state.position].name))/2;
      int y = u8g2_GetDisplayHeight(u8g2)-5;
      u8g2_DrawStr(u8g2, x, y, menu_entry_list[destination_state.position].name);
      
      check_button_event();
      delay_1ms(10);
    } while( u8g2_NextPage(u8g2) );
    printf("%d==========\r\n",button_event);
    if ( button_event == U8X8_MSG_GPIO_MENU_NEXT )
      to_right(u8g2,&destination_state);
    if ( button_event == U8X8_MSG_GPIO_MENU_PREV )
      to_left(&destination_state);
    if ( button_event == U8X8_MSG_GPIO_MENU_SELECT )
    {
      u8g2_SetFont(u8g2,u8g2_font_helvB10_tr);  
      u8g2_UserInterfaceMessage(u8g2,"Selection:", menu_entry_list[destination_state.position].name, "", " Ok ");
    }
    if ( button_event > 0 )	// all known events are processed, clear event
      button_event = 0;
  } while ( towards(&current_state, &destination_state) );
}


static void setup(u8g2_t* u8g2) {
  
  // DOGS102 Shield (http://shieldlist.org/controlconnection/dogs102)
  //u8g2.begin(/* menu_select_pin= */ 5, /* menu_next_pin= */ 4, /* menu_prev_pin= */ 2, /* menu_home_pin= */ 3);
  
  u8g2_InitDisplay(u8g2); // send init sequence to the display, display is in sleep mode after this,
  u8g2_SetPowerSave(u8g2, 0); // wake up display

  u8g2_SetFont(u8g2,u8g2_font_6x12_tr);
}

int main(){
	systick_config();
	USART0_init();
	
  gpio_i2c_init();
//  gpio_spi_init();
  
  Keys_init();
  
	u8g2_t u8g2_i2c;
  u8g2_t u8g2_spi;
 
  
  u8g2_Setup_ssd1306_i2c_128x64_noname_f(&u8g2_i2c, U8G2_R0, u8x8_byte_sw_i2c, u8g2_gpio_and_delay_gd32);
//  u8g2_Setup_ssd1306_128x64_noname_f(&u8g2_spi, U8G2_R0, u8x8_byte_4wire_sw_spi, u8g2_gpio_and_delay_gd32);
  
  setup(&u8g2_i2c);
  //setup(&u8g2_spi);
  
  while(1){
    loop(&u8g2_i2c);
    //loop(&u8g2_spi);
  }
	
	return 0;
}