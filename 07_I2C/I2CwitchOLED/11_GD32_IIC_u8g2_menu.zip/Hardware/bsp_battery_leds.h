#ifndef __Battery_leds_H__
#define __Battery_leds_H__

#include "gd32f4xx.h"

//#define LED_SW	GPIOC, GPIO_PIN_6
//#define LED1		GPIOD, GPIO_PIN_8
//#define LED2		GPIOD, GPIO_PIN_9
//#define LED3		GPIOD, GPIO_PIN_10
//#define LED4		GPIOD, GPIO_PIN_11

typedef enum {

	LED1 = 1,
	LED2,
	LED3,
	LED4,
	
}LED_enum;
void Battery_leds_init();

// ����ָ����
void Battery_leds_turn_on(uint8_t led_index);

// Ϩ��ָ����
void Battery_leds_turn_off(uint8_t led_index);

// ��ˮ��
void Battery_leds_start(uint8_t power);

// ���µ�ǰ����
void Battery_leds_update(uint8_t power);

// ѭ������
void Battery_leds_loop();

void Battery_leds_stop();

#endif
