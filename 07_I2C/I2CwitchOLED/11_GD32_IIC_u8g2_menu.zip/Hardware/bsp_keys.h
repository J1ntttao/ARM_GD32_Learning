#ifndef __BSP_KEYS_H__
#define __BSP_KEYS_H__

#include "gd32f4xx.h"

#ifndef u8
#define u8 uint8_t
#endif

#ifndef u16
#define u16 uint16_t
#endif

#ifndef u32
#define u32 uint32_t
#endif

void Keys_init();

int8_t Keys_scan();

extern void Keys_on_keydown(uint8_t index);
extern void Keys_on_keyup(uint8_t index);

#endif
