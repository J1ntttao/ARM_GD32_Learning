#ifndef __EXTI_H__
#define __EXTI_H__

#include "gd32f4xx.h"
#include "gd32f4xx_exti.h"
#include "EXTI_config.h"

void EXTI_init();

/*!
    \brief    ��������ָ���ⲿ�ж�
    \param[in]  linex: EXTI line number, refer to exti_line_enum
                only one parameter can be selected which is shown as below:
      \arg        EXTI_x (x=0..22): EXTI line x
*/
void EXTI_trig_soft(exti_line_enum linex);

extern void EXTI0_on_trig();
extern void EXTI1_on_trig();
extern void EXTI2_on_trig();
extern void EXTI5_on_trig();
extern void EXTI6_on_trig();

//extern void EXTI_on_trig(exti_line_enum linex);

#endif